# BẮT ĐẦU NHANH – CẦM TAY CHỈ VIỆC

1. Giải nén ZIP ở nơi dễ tìm, ví dụ `D:\DuAn\TourGo_Java21_Full_VSCode_PgAdmin4`.
2. Mở pgAdmin 4 → Databases → Create → Database → `tourgo_fresh` (để tách với bản cũ bị 403).
3. Mở VS Code → File → Open Folder → chọn thư mục chứa `pom.xml`.
4. Mở `.vscode/launch.json` và thay hai dòng:
   - `DB_URL` = `jdbc:postgresql://localhost:5432/tourgo_fresh`
   - `DB_PASSWORD` = mật khẩu **PostgreSQL postgres** của bạn.
5. Nhấn `Ctrl+Shift+D` → chọn **TourGo - F5 (PostgreSQL)** → nhấn `F5`.
6. Chờ `Started TourGoApplication` trong Debug Console hoặc Terminal.
7. Mở Chrome → `http://localhost:8080/login`.
8. Admin: `admin@tourgo.local` / `Admin@12345`.
9. Customer: `khach@tourgo.local` / `Customer@12345`.

Nếu bị lỗi, chụp **phần cuối Terminal** sau F5; xem bảng lỗi trong README.md.
