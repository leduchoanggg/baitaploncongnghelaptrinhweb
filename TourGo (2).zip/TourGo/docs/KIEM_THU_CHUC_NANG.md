# KIỂM THỬ CHỨC NĂNG TOURGO – THỰC HIỆN TRONG VS CODE

## Chạy tự động

Mở Terminal (Ctrl+`), gõ `mvn clean test`. Bộ test trong `src/test/java/com/tourgo/TourGoFlowTest.java` sử dụng H2 độc lập PostgreSQL để kiểm tra:

1. Trang chủ / login / register / chi tiết tour trả 200.
2. Admin truy cập được /admin và giao diện quản trị; Customer bị 403 khi vào /admin.
3. Customer truy cập được lịch sử cá nhân; Admin không thể truy cập khu vực Customer.
4. Đăng nhập Admin với mật khẩu demo chuyển đúng /admin; giữ session qua request tiếp theo.
5. POST login thiếu CSRF bị chặn 403 đúng thiết kế.
6. Đặt tour giữ chỗ; hủy đơn chờ duyệt thì trả lại số chỗ.

## Chạy thủ công với PostgreSQL / pgAdmin 4

1. Trong `tourgo_fresh`, kiểm tra có 4 bảng và dữ liệu seed bằng SQL file 02.
2. Vào `/login` bằng Customer `khach@tourgo.local` / `Customer@12345`.
3. Chọn tour, lịch khởi hành còn chỗ, nhập số người (ví dụ 2), số điện thoại. Gửi đơn.
4. Trong `/customer/bookings`, thấy trạng thái **PENDING** và tổng tiền.
5. Đăng xuất qua nút **Đăng xuất** (POST có CSRF).
6. Đăng nhập Admin `admin@tourgo.local` / `Admin@12345`, vào `/admin/bookings`.
7. Nhấn **Duyệt** trên đúng đơn. Trạng thái chuyển sang **CONFIRMED**.
8. Đăng xuất, đăng nhập lại Customer. Trong `/customer/bookings` thấy CONFIRMED.
9. Lặp lại với đơn khác rồi **Từ chối**, kiểm tra chỗ trống tăng trở lại.
10. Trong Admin → Tour → Thêm tour, thử tạo tour. Admin → Lịch khởi hành → Thêm lịch, thử đặt bằng Customer.
11. Đăng nhập Customer và nhập `/admin`: phải bị 403. Đây là kết quả **mong muốn**, không phải lỗi.

## Nếu kiểm thử báo lỗi

Sao chép 30–50 dòng cuối Terminal, bao gồm `Caused by:` và dòng đầu `ERROR`, để xác định nguyên nhân chính xác. Không tắt CSRF, không cho phép `/admin/**` công khai để né lỗi.
