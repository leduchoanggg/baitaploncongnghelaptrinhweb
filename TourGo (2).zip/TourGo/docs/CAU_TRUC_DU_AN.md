# CẤU TRÚC VÀ THIẾT KẾ TOURGO

## Kiến trúc MVC

- `config/SecurityConfig.java`: Spring Security, BCrypt, phân quyền, chuyển trang sau login.
- `config/DemoData.java`: tạo demo một lần nếu chưa có tài khoản hoặc tour, không đè dữ liệu hiện hữu.
- `model/`: các Entity ánh xạ database.
- `repository/`: Spring Data JPA giao tiếp PostgreSQL.
- `service/BookingService.java`: đặt, duyệt, từ chối, hủy; khóa dòng chống overbooking.
- `service/DepartureService.java`: thêm/sửa/ẩn lịch và không cho giảm sức chứa thấp hơn số đã đặt.
- `web/PublicController.java`: giao diện công khai, đăng ký, đăng nhập.
- `web/CustomerController.java`: đặt tour, lịch sử, hủy đơn của chính khách.
- `web/AdminController.java`: dashboard, tour, lịch, đơn, khách hàng.
- `web/form/`: DTO kèm validation, không cho khách sửa quyền trực tiếp.
- `resources/templates/`: trang Thymeleaf (Admin/Customer riêng).
- `.vscode/launch.json`: cấu hình F5, chỉ cần sửa mật khẩu PostgreSQL.

## Bảng dữ liệu và quan hệ

```text
app_users (id, full_name, email UNIQUE, password_hash, role, created_at)
        1 │
          └──────< bookings (id, customer_id, departure_id, travelers,
                      contact_name, contact_phone, note, total_price,
                      status, created_at)
                          >────── 1 tour_departures (id, tour_id, start_date,
                                    capacity, available_seats, active, version)
                                             >────── 1 tours (id, title,
                                                origin, destination,
                                                duration_days, price, summary,
                                                description, theme, active)
```

## Luồng xử lý đặt tour

1. Customer đăng nhập: `SecurityConfig` nhận user qua email, authority `ROLE_CUSTOMER`.
2. Customer chọn tour, lịch và số người, POST `/customer/bookings` có CSRF token.
3. `BookingService.place` khóa lịch khởi hành (`PESSIMISTIC_WRITE`), kiểm tra tour mở, ngày còn trong tương lai và số chỗ.
4. Giảm `availableSeats`, tạo đơn `PENDING` và lưu `totalPrice` tại thời điểm đặt (snapshot).
5. Admin duyệt → `CONFIRMED`; số chỗ tiếp tục được giữ. Admin từ chối → `REJECTED`, trả chỗ.
6. Customer chỉ được tự hủy đơn `PENDING`, sau đó trả chỗ.
7. Dashboard cộng `totalPrice` các đơn `CONFIRMED`, không tính đơn PENDING/REJECTED/CANCELLED.

## Bảo mật

- Customer **không được** vào `/admin/**` (403 là đúng).
- Admin **không được** vào `/customer/**`.
- Form POST luôn có `_csrf`; CSRF **không tắt**.
- Mật khẩu là hash BCrypt, không lưu mật khẩu bản rõ trong database.
- Mọi đăng ký mới nhận `UserRole.CUSTOMER`, không có input `role`.
- Tất cả đường dẫn quản trị được Spring Security kiểm soát ở server.

## Phạm vi

Đây là hệ thống học tập hoàn chỉnh cho luồng tour → lịch → đặt → xét duyệt → báo cáo. Không tích hợp thanh toán trực tuyến hoặc email xác nhận tự động. Dùng production phải thiết lập Flyway, phân quyền phức tạp hơn, logs/audit, secret management, giám sát, backup, chống spam, rate limit, và cơ chế hoàn tiền.
