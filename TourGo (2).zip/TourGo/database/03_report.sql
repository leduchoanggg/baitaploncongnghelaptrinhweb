USE tourgo_fresh;
GO

-- Thống kê đơn hàng theo trạng thái
SELECT
    status,
    COUNT(*) AS total_orders,
    COALESCE(SUM(total_price), 0) AS total_value
FROM bookings
GROUP BY status
ORDER BY status;

-- Thống kê số đơn đã xác nhận và doanh thu theo tour
SELECT
    t.title AS tour,
    SUM(
        CASE
            WHEN b.status = 'CONFIRMED' THEN 1
            ELSE 0
        END
    ) AS confirmed_bookings,
    COALESCE(
        SUM(
            CASE
                WHEN b.status = 'CONFIRMED' THEN b.total_price
                ELSE 0
            END
        ), 0
    ) AS confirmed_revenue
FROM tours t
LEFT JOIN tour_departures d ON d.tour_id = t.id
LEFT JOIN bookings b ON b.departure_id = d.id
GROUP BY t.id, t.title
ORDER BY confirmed_revenue DESC;