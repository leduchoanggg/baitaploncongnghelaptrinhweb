USE tourgo_fresh;
GO

-- Kiểm tra tài khoản
SELECT id, full_name, email, role, created_at
FROM app_users
ORDER BY id;

-- Kiểm tra tour
SELECT id, title, destination, price, active
FROM tours
ORDER BY id;

-- Kiểm tra lịch khởi hành
SELECT id, tour_id, start_date, capacity, available_seats, active
FROM tour_departures
ORDER BY start_date;

-- Kiểm tra đơn đặt tour
SELECT id, customer_id, departure_id, travelers,
       total_price, status, created_at
FROM bookings
ORDER BY id DESC;