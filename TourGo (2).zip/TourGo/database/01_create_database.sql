USE master;
GO

IF DB_ID(N'tourgo_fresh') IS NULL
BEGIN
    CREATE DATABASE tourgo_fresh;
END
GO