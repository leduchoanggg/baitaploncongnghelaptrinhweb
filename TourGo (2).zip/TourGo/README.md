# TOURGO – WEBSITE QUẢN LÝ TOUR (JAVA 21 + VS CODE + PGADMIN 4)

Đây là **bản project làm lại độc lập**. Không sao chép đè vào project cũ đang bị lỗi 403.

## 1. Công nghệ

- Java 21, Spring Boot 3.5.6, Spring Security 6, Spring MVC, Thymeleaf
- JPA / Hibernate, PostgreSQL, quản trị database bằng pgAdmin 4
- Maven, VS Code + Extension Pack for Java, Spring Boot Extension Pack
- Spring Security: mật khẩu BCrypt, ADMIN/CUSTOMER tách biệt, CSRF được bật
- Chạy bằng F5 trong VS Code thông qua `.vscode/launch.json`

## 2. Cài đặt (Windows)

1. Cài **JDK 21** (đã biết thư mục ví dụ của bạn: `C:\Program Files\Java\jdk-21.0.12`).
2. Cài **PostgreSQL và pgAdmin 4**. Ghi nhớ mật khẩu role `postgres`.
3. Cài **VS Code** và hai extension `Extension Pack for Java` và `Spring Boot Extension Pack`.
4. Cài **Apache Maven 3.9+**. Nếu `mvn -version` không chạy được, thêm thư mục `bin` của Maven vào PATH.
5. Mở PowerShell để kiểm tra:

   ```powershell
   & "C:\Program Files\Java\jdk-21.0.12\bin\java.exe" -version
   java -version
   javac -version
   mvn -version
   ```

   Nếu `java -version` vẫn là Java 8 (đường dẫn `java8path` của Oracle), hãy chỉnh `JAVA_HOME` thành thư mục JDK 21, đưa `%JAVA_HOME%\bin` lên trước `java8path` trong PATH và mở VS Code lại.

## 3. Tạo database trong pgAdmin 4

1. Mở pgAdmin 4 → Servers → PostgreSQL → Databases.
2. Nếu chưa có database `tourgo_fresh`: chuột phải **Databases → Create → Database...** → Database = `tourgo_fresh` → Save.
3. Hoặc chọn database `postgres` → Query Tool và chạy `database/01_create_database.sql`.
4. **Chỉ cần tạo database.** KHÔNG chạy script tạo bảng. Hibernate tự tạo bảng `app_users`, `tours`, `tour_departures`, `bookings` khi Spring Boot chạy lần đầu.

## 4. MỞ PROJECT VÀ CHẠY NGAY TRONG VS CODE (F5)

1. **Giải nén ZIP**, sau đó File → Open Folder trong VS Code; chọn **chính thư mục chứa `pom.xml` và `.vscode`**.
2. Chờ phần `JAVA PROJECTS`/`MAVEN` load. Lần đầu Maven tải thư viện qua Internet, nên cần kết nối mạng.
3. Mở `.vscode/launch.json`, tìm:

   ```json
   "DB_PASSWORD": "THAY_MAT_KHAU_POSTGRES"
   ```

   Thay bằng **mật khẩu PostgreSQL của bạn**, không phải Master Password của pgAdmin. Nếu mật khẩu có dấu `\` hoặc `"`, cần escape hợp lệ theo JSON.
4. Nhấn **Ctrl+Shift+D** → chọn `TourGo - F5 (PostgreSQL)` → nhấn **F5**.
5. Chờ `Started TourGoApplication` ở Terminal/Debug Console, truy cập **http://localhost:8080**.
6. Vào **http://localhost:8080/login** để đăng nhập.

**Nếu không thấy lựa chọn F5:** Ctrl+Shift+P → `Java: Import Java Projects into Workspace`, sau đó Ctrl+Shift+P → `Developer: Reload Window`.

**Nếu muốn chạy bằng Terminal của VS Code thay cho F5:**

```powershell
$env:DB_PASSWORD="MAT_KHAU_POSTGRES_CUA_BAN"
mvn spring-boot:run
```

**Build / tự kiểm tra project:**

```powershell
mvn clean test
mvn clean package
```

Thư mục `src/test/` có kiểm thử trang chủ, login, phân quyền 403 đúng trường hợp, CSRF và nghiệp vụ đặt/hủy tour với database H2 riêng. Lệnh `mvn test` không yêu cầu PostgreSQL (H2 chỉ dành cho test).

## 5. Tài khoản demo

| Vai trò | Email | Mật khẩu | Link |
|---|---|---|---|
| ADMIN | `admin@tourgo.local` | `Admin@12345` | http://localhost:8080/admin |
| CUSTOMER | `khach@tourgo.local` | `Customer@12345` | http://localhost:8080/customer/bookings |

Lần đầu chạy, cấu hình `app.seed-demo=true` tạo 2 tài khoản đã mã hóa BCrypt, 4 tour và 6 lịch khởi hành trong tương lai. Nếu tài khoản đã tồn tại, seeder **không thay đổi** mật khẩu hoặc quyền cũ. Project **mặc định sử dụng database `tourgo_fresh` hoàn toàn mới** để tránh xung đột cấu trúc và dữ liệu của TourGo cũ.

## 6. Chức năng và đường dẫn

**CUSTOMER**

- `/` hoặc `/tours`: danh sách tour, tìm theo tên, nơi đi hoặc điểm đến
- `/tours/{id}`: chi tiết tour, lịch khởi hành, số chỗ trống
- `/register`, `/login`: đăng ký tài khoản khách, đăng nhập
- `/customer/bookings`: xem trạng thái đơn và hủy đơn PENDING

**ADMIN**

- `/admin`: dashboard (tổng tour, khách, đơn, doanh thu xác nhận)
- `/admin/tours`: thêm/sửa/ẩn/hiện tour
- `/admin/departures`: thêm/sửa/ẩn/hiện lịch khởi hành, chỉnh số chỗ
- `/admin/bookings`: duyệt hoặc từ chối đơn; từ chối hoàn chỗ
- `/admin/customers`: danh sách tài khoản khách

**Luồng kiểm thử thủ công:** Khách đăng nhập → chọn tour có lịch còn chỗ → đặt 2 người → xem đơn PENDING → đăng xuất (nút ở header) → Admin đăng nhập → xem đơn và duyệt → đăng xuất → khách đăng nhập lại → xem đơn CONFIRMED.

## 7. Vì sao dùng database MỚI, tránh lỗi của bản trước

Nếu bạn đã dùng `tourgo_db` cho project cũ, database đó có thể có bảng/role/schema **khác** project mới. Để không xóa dữ liệu cũ:

- Trong pgAdmin, tạo database tên `tourgo_fresh` (Databases → Create → Database).
- `.vscode/launch.json` đã đặt `DB_URL=jdbc:postgresql://localhost:5432/tourgo_fresh` sẵn; không cần đổi trừ khi bạn đặt tên database khác.
- Chạy F5 lại. Lúc này Hibernate sẽ tạo 4 bảng sạch, tài khoản demo đúng quyền.

Đừng DROP `tourgo_db` cũ khi chưa sao lưu.

## 8. Lỗi thường gặp

| Thông báo | Giải pháp |
|---|---|
| `password authentication failed for user postgres` | Mật khẩu PostgreSQL sai ở `launch.json`; thử pgAdmin kết nối lại role postgres. |
| `database ... does not exist` | Database chưa được tạo, kiểm tra `DB_URL`. |
| `Connection refused` | PostgreSQL chưa chạy; kiểm tra Windows Services → postgresql-x64-... và port 5432. |
| `Port 8080 already in use` | Dừng project cũ bằng Shift+F5, hoặc đổi `PORT` trong launch env. |
| `mvn not recognized` | Cài Apache Maven, thêm thư mục `bin` Maven vào PATH, mở VS Code lại. |
| `java.home ... jdk-17 missing` | VS Code User Settings (JSON) xóa đường dẫn Java 17 không còn tồn tại, đặt `java.jdt.ls.java.home` là đường dẫn JDK 21 thực tế. |
| `403` khi khách vào `/admin` | Đây là phân quyền **đúng**. Đăng xuất bằng form và đăng nhập Admin. |
| `403` ngay khi POST `/login` hoặc bấm Duyệt | CSRF token bị thiếu (không copy form từ bản cũ); dùng file HTML của project mới. |
| `403` dù tài khoản đúng | Xem `app_users.role` trong database **được chỉ bởi DB_URL**; không chỉnh quyền bừa. Test phân quyền: `mvn test`. |
| `relation ... does not exist` | App chưa chạy xong, hoặc Query Tool mở nhầm database. |

## 9. Kiểm tra PostgreSQL bằng pgAdmin 4

Chọn database `tourgo_fresh` → Query Tool → mở `database/02_check_database.sql`, Execute (F5). File `03_report.sql` có SQL thống kê đơn/doanh thu.

## 10. Giới hạn và lưu ý

- Đây là **website mẫu/đồ án**, chưa có thanh toán online, cổng email/SMS, ảnh tải lên, mã giảm giá, phân trang hay hóa đơn PDF.
- Dữ liệu seed và mật khẩu demo chỉ dùng cho môi trường phát triển. Không đưa lên website công khai với tài khoản mặc định.
- `spring.jpa.hibernate.ddl-auto=update` thuận tiện cho đồ án, khi vận hành thật phải chuyển sang migrations (Flyway/Liquibase) và bảo vệ secrets bằng biến môi trường.
- Mật khẩu trong `.vscode/launch.json` chỉ dùng trên máy cá nhân và **không đưa file có mật khẩu thật lên GitHub**.
- Báo cáo dựa trên số tiền snapshot của đơn CONFIRMED (không phải số tiền thực thu qua cổng thanh toán).
