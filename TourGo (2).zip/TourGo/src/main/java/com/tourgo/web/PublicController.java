package com.tourgo.web;

import com.tourgo.model.*;
import com.tourgo.repository.*;
import com.tourgo.web.form.RegisterForm;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;
import java.util.Locale;

@Controller
public class PublicController {
    private final TourRepository tours;
    private final DepartureRepository departures;
    private final UserRepository users;
    private final PasswordEncoder encoder;
    public PublicController(TourRepository tours, DepartureRepository departures,
                            UserRepository users, PasswordEncoder encoder) {
        this.tours=tours; this.departures=departures; this.users=users; this.encoder=encoder;
    }

    @GetMapping({"/", "/tours"})
    public String home(@RequestParam(defaultValue="") String q, Model model) {
        model.addAttribute("tours", tours.searchActive(q.trim()));
        model.addAttribute("q", q.trim());
        model.addAttribute("tourCount", tours.countByActiveTrue());
        return "home";
    }

    @GetMapping("/tours/{id}")
    public String tour(@PathVariable Long id, Model model) {
        Tour tour = tours.findById(id).orElseThrow(() -> new org.springframework.web.server.ResponseStatusException(
            org.springframework.http.HttpStatus.NOT_FOUND, "Tour không tồn tại"));
        if (!tour.isActive()) throw new org.springframework.web.server.ResponseStatusException(
            org.springframework.http.HttpStatus.NOT_FOUND, "Tour không mở bán");
        model.addAttribute("tour", tour);
        model.addAttribute("departures", departures
            .findByTourIdAndActiveTrueAndStartDateGreaterThanEqualOrderByStartDateAsc(id, LocalDate.now().plusDays(1))
            .stream().filter(d -> d.getAvailableSeats() > 0).toList());
        return "tour-detail";
    }

    @GetMapping("/login")
    public String login(Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()
            && !(authentication instanceof AnonymousAuthenticationToken)) {
            boolean admin = authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
            return "redirect:" + (admin ? "/admin" : "/customer/bookings");
        }
        return "login";
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("registerForm", new RegisterForm());
        return "register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("registerForm") RegisterForm form,
                           BindingResult errors, RedirectAttributes flash) {
        if (!java.util.Objects.equals(form.getPassword(), form.getConfirmPassword()))
            errors.rejectValue("confirmPassword", "mismatch", "Hai mật khẩu không khớp");
        if (errors.hasErrors()) return "register";

        String email = form.getEmail().trim().toLowerCase(Locale.ROOT);

        if (users.existsByEmailIgnoreCase(email)) {
            errors.rejectValue("email", "exists", "Email này đã được sử dụng");
            return "register";
        }
        AppUser u = new AppUser();
        u.setFullName(form.getFullName().trim());
        u.setEmail(email);
        u.setPasswordHash(encoder.encode(form.getPassword()));
        u.setRole(UserRole.CUSTOMER); // tuyệt đối không nhận quyền từ form của khách
        try {
            users.saveAndFlush(u);
        } catch (DataIntegrityViolationException ex) {
            errors.rejectValue("email", "exists", "Email đã được đăng ký, vui lòng thử email khác");
            return "register";
        }
        flash.addFlashAttribute("success", "Tạo tài khoản thành công. Hãy đăng nhập để đặt tour.");
        return "redirect:/login";
    }
}
