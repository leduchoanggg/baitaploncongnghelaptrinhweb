package com.tourgo.web.form;

import com.tourgo.model.TourDeparture;
import jakarta.validation.constraints.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;

public class DepartureForm {
    @NotNull(message="Chọn tour")
    private Long tourId;
    @NotNull(message="Chọn ngày khởi hành") @Future(message="Ngày phải trong tương lai")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate startDate;
    @Min(value=1,message="Tối thiểu 1 chỗ") @Max(value=1000,message="Tối đa 1.000 chỗ")
    private int capacity = 20;
    private boolean active = true;

    public static DepartureForm from(TourDeparture d) {
        DepartureForm f=new DepartureForm(); f.tourId=d.getTour().getId();
        f.startDate=d.getStartDate(); f.capacity=d.getCapacity(); f.active=d.isActive();
        return f;
    }
    public Long getTourId() { return tourId; } public void setTourId(Long x) { tourId=x; }
    public LocalDate getStartDate() { return startDate; } public void setStartDate(LocalDate x) { startDate=x; }
    public int getCapacity() { return capacity; } public void setCapacity(int x) { capacity=x; }
    public boolean isActive() { return active; } public void setActive(boolean x) { active=x; }
}
