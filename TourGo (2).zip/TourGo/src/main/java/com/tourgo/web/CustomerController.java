package com.tourgo.web;

import com.tourgo.repository.*;
import com.tourgo.service.BookingService;
import com.tourgo.web.form.BookingForm;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/customer")
public class CustomerController {
    private final UserRepository users;
    private final BookingRepository bookings;
    private final BookingService bookingService;
    public CustomerController(UserRepository users, BookingRepository bookings, BookingService bookingService) {
        this.users=users; this.bookings=bookings; this.bookingService=bookingService;
    }

    @GetMapping({"", "/bookings"})
    public String history(Authentication auth, Model model) {
        var user = users.findByEmailIgnoreCase(auth.getName()).orElseThrow();
        model.addAttribute("bookings", bookings.findByCustomerIdOrderByIdDesc(user.getId()));
        model.addAttribute("currentUser", user);
        return "customer/bookings";
    }

    @PostMapping("/bookings")
    public String book(@Valid @ModelAttribute BookingForm form, BindingResult errors,
                       Authentication auth, RedirectAttributes flash) {
        if (errors.hasErrors()) {
            flash.addFlashAttribute("error", "Thông tin đặt tour không hợp lệ. Kiểm tra ngày, số khách và số điện thoại.");
            return "redirect:/tours";
        }
        try {
            bookingService.place(form, auth.getName());
            flash.addFlashAttribute("success", "Đã gửi yêu cầu đặt tour! Vui lòng chờ Admin xác nhận.");
            return "redirect:/customer/bookings";
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
            return "redirect:/tours";
        }
    }

    @PostMapping("/bookings/{id}/cancel")
    public String cancel(@PathVariable Long id, Authentication auth, RedirectAttributes flash) {
        try {
            bookingService.cancelByCustomer(id, auth.getName());
            flash.addFlashAttribute("success", "Đã hủy đơn đặt tour và hoàn lại số chỗ.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/customer/bookings";
    }
}
