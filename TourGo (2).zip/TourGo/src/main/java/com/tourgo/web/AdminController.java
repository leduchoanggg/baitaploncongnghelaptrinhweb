package com.tourgo.web;

import com.tourgo.model.*;
import com.tourgo.repository.*;
import com.tourgo.service.*;
import com.tourgo.web.form.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.math.BigDecimal;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final TourRepository tours;
    private final DepartureRepository departures;
    private final BookingRepository bookings;
    private final UserRepository users;
    private final BookingService bookingService;
    private final DepartureService departureService;

    public AdminController(TourRepository tours, DepartureRepository departures,
                           BookingRepository bookings, UserRepository users,
                           BookingService bookingService, DepartureService departureService) {
        this.tours=tours; this.departures=departures; this.bookings=bookings;
        this.users=users; this.bookingService=bookingService; this.departureService=departureService;
    }

    @GetMapping({"", "/"})
    public String dashboard(Model model) {
        model.addAttribute("tourCount", tours.count());
        model.addAttribute("customerCount", users.findByRoleOrderByIdDesc(UserRole.CUSTOMER).size());
        model.addAttribute("bookingCount", bookings.count());
        model.addAttribute("pendingCount", bookings.countByStatus(BookingStatus.PENDING));
        BigDecimal revenue = bookings.sumByStatus(BookingStatus.CONFIRMED);
        model.addAttribute("revenue", revenue == null ? BigDecimal.ZERO : revenue);
        model.addAttribute("recentBookings", bookings.findAllByOrderByIdDesc().stream().limit(8).toList());
        return "admin/dashboard";
    }

    @GetMapping("/tours")
    public String tours(Model model) {
        model.addAttribute("tours", tours.findAllByOrderByIdDesc());
        return "admin/tours";
    }

    @GetMapping("/tours/new")
    public String newTour(Model model) {
        model.addAttribute("tourForm", new TourForm());
        model.addAttribute("editId", null);
        return "admin/tour-form";
    }

    @GetMapping("/tours/{id}/edit")
    public String editTour(@PathVariable Long id, Model model) {
        Tour t = getTour(id);
        model.addAttribute("tourForm", TourForm.from(t));
        model.addAttribute("editId", id);
        return "admin/tour-form";
    }

    @PostMapping("/tours")
    public String createTour(@Valid @ModelAttribute("tourForm") TourForm form, BindingResult errors,
                             Model model, RedirectAttributes flash) {
        if (errors.hasErrors()) {
            model.addAttribute("editId", null);
            return "admin/tour-form";
        }
        Tour t = new Tour(); form.apply(t); tours.save(t);
        flash.addFlashAttribute("success", "Đã tạo tour mới.");
        return "redirect:/admin/tours";
    }

    @PostMapping("/tours/{id}")
    public String updateTour(@PathVariable Long id, @Valid @ModelAttribute("tourForm") TourForm form,
                             BindingResult errors, Model model, RedirectAttributes flash) {
        if (errors.hasErrors()) {
            model.addAttribute("editId", id);
            return "admin/tour-form";
        }
        Tour t = getTour(id); form.apply(t); tours.save(t);
        flash.addFlashAttribute("success", "Đã cập nhật tour.");
        return "redirect:/admin/tours";
    }

    @PostMapping("/tours/{id}/toggle")
    public String toggleTour(@PathVariable Long id, RedirectAttributes flash) {
        Tour t = getTour(id); t.setActive(!t.isActive()); tours.save(t);
        flash.addFlashAttribute("success", "Đã thay đổi trạng thái tour.");
        return "redirect:/admin/tours";
    }

    @GetMapping("/departures")
    public String departures(Model model) {
        model.addAttribute("departures", departures.findAllByOrderByStartDateAsc());
        return "admin/departures";
    }

    @GetMapping("/departures/new")
    public String newDeparture(@RequestParam(required=false) Long tourId, Model model) {
        DepartureForm f = new DepartureForm(); f.setTourId(tourId);
        model.addAttribute("departureForm", f);
        model.addAttribute("editId", null);
        model.addAttribute("tours", tours.findAllByOrderByIdDesc());
        return "admin/departure-form";
    }

    @GetMapping("/departures/{id}/edit")
    public String editDeparture(@PathVariable Long id, Model model) {
        TourDeparture d = getDeparture(id);
        model.addAttribute("departureForm", DepartureForm.from(d));
        model.addAttribute("editId", id);
        model.addAttribute("tours", tours.findAllByOrderByIdDesc());
        return "admin/departure-form";
    }

    @PostMapping("/departures")
    public String createDeparture(@Valid @ModelAttribute("departureForm") DepartureForm form,
                                  BindingResult errors, Model model, RedirectAttributes flash) {
        return saveDeparture(null, form, errors, model, flash);
    }

    @PostMapping("/departures/{id}")
    public String updateDeparture(@PathVariable Long id,
                                  @Valid @ModelAttribute("departureForm") DepartureForm form,
                                  BindingResult errors, Model model, RedirectAttributes flash) {
        return saveDeparture(id, form, errors, model, flash);
    }

    private String saveDeparture(Long id, DepartureForm form, BindingResult errors,
                                 Model model, RedirectAttributes flash) {
        if (!errors.hasErrors()) {
            try {
                departureService.save(id, form);
                flash.addFlashAttribute("success", "Đã lưu lịch khởi hành.");
                return "redirect:/admin/departures";
            } catch (IllegalArgumentException ex) {
                errors.reject("invalid", ex.getMessage());
            }
        }
        model.addAttribute("editId", id);
        model.addAttribute("tours", tours.findAllByOrderByIdDesc());
        return "admin/departure-form";
    }

    @PostMapping("/departures/{id}/toggle")
    public String toggleDeparture(@PathVariable Long id, RedirectAttributes flash) {
        try {
            departureService.toggle(id);
            flash.addFlashAttribute("success", "Đã thay đổi trạng thái lịch khởi hành.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/admin/departures";
    }

    @GetMapping("/bookings")
    public String bookings(Model model) {
        model.addAttribute("bookings", bookings.findAllByOrderByIdDesc());
        return "admin/bookings";
    }

    @PostMapping("/bookings/{id}/confirm")
    public String confirm(@PathVariable Long id, RedirectAttributes flash) {
        return changeBooking(id, BookingStatus.CONFIRMED, flash);
    }

    @PostMapping("/bookings/{id}/reject")
    public String reject(@PathVariable Long id, RedirectAttributes flash) {
        return changeBooking(id, BookingStatus.REJECTED, flash);
    }

    private String changeBooking(Long id, BookingStatus status, RedirectAttributes flash) {
        try {
            bookingService.adminChangeStatus(id, status);
            flash.addFlashAttribute("success", status == BookingStatus.CONFIRMED
                ? "Đã xác nhận đặt tour." : "Đã từ chối đơn và hoàn lại số chỗ.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/admin/bookings";
    }

    @GetMapping("/customers")
    public String customers(Model model) {
        model.addAttribute("customers", users.findByRoleOrderByIdDesc(UserRole.CUSTOMER));
        return "admin/customers";
    }

    private Tour getTour(Long id) {
        return tours.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }
    private TourDeparture getDeparture(Long id) {
        return departures.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }
}
