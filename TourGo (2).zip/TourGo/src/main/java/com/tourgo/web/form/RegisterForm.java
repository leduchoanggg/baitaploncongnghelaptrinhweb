package com.tourgo.web.form;

import jakarta.validation.constraints.*;

public class RegisterForm {
    @NotBlank(message = "Vui lòng nhập họ tên")
    @Size(max = 120)
    private String fullName;
    @NotBlank(message = "Vui lòng nhập email")
    @Email(message = "Email không hợp lệ")
    private String email;
    @NotBlank(message = "Vui lòng nhập mật khẩu")
    @Size(min = 8, max = 72, message = "Mật khẩu phải từ 8 ký tự")
    private String password;
    @NotBlank(message = "Vui lòng xác nhận mật khẩu")
    private String confirmPassword;
    public String getFullName() { return fullName; }
    public void setFullName(String x) { fullName = x; }
    public String getEmail() { return email; }
    public void setEmail(String x) { email = x; }
    public String getPassword() { return password; }
    public void setPassword(String x) { password = x; }
    public String getConfirmPassword() { return confirmPassword; }
    public void setConfirmPassword(String x) { confirmPassword = x; }
}
