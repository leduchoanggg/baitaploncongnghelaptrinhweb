package com.tourgo.web.form;

import com.tourgo.model.Tour;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class TourForm {
    @NotBlank(message="Cần nhập tên tour") @Size(max=150)
    private String title;
    @NotBlank(message="Cần nhập điểm đến") @Size(max=100)
    private String destination;
    @NotBlank(message="Cần nhập điểm đi") @Size(max=100)
    private String origin;
    @Min(value=1,message="Tối thiểu 1 ngày") @Max(value=60,message="Tối đa 60 ngày")
    private int durationDays = 3;
    @NotNull(message="Cần nhập giá") @DecimalMin(value="1000", message="Giá tối thiểu 1.000đ")
    private BigDecimal price;
    @NotBlank(message="Cần nhập mô tả ngắn") @Size(max=300)
    private String summary;
    @Size(max=8000)
    private String description;
    @NotBlank(message="Cần chọn chủ đề")
    @Pattern(regexp="sea|mountain|city|forest",message="Chủ đề không hợp lệ")
    private String theme = "sea";
    private boolean active = true;

    public static TourForm from(Tour t) {
        TourForm f = new TourForm();
        f.title=t.getTitle(); f.destination=t.getDestination(); f.origin=t.getOrigin();
        f.durationDays=t.getDurationDays(); f.price=t.getPrice(); f.summary=t.getSummary();
        f.description=t.getDescription(); f.theme=t.getTheme(); f.active=t.isActive();
        return f;
    }
    public void apply(Tour t) {
        t.setTitle(title.trim()); t.setDestination(destination.trim()); t.setOrigin(origin.trim());
        t.setDurationDays(durationDays); t.setPrice(price); t.setSummary(summary.trim());
        t.setDescription(description == null ? "" : description.trim()); t.setTheme(theme);
        t.setActive(active);
    }
    public String getTitle() { return title; } public void setTitle(String x) { title=x; }
    public String getDestination() { return destination; } public void setDestination(String x) { destination=x; }
    public String getOrigin() { return origin; } public void setOrigin(String x) { origin=x; }
    public int getDurationDays() { return durationDays; } public void setDurationDays(int x) { durationDays=x; }
    public BigDecimal getPrice() { return price; } public void setPrice(BigDecimal x) { price=x; }
    public String getSummary() { return summary; } public void setSummary(String x) { summary=x; }
    public String getDescription() { return description; } public void setDescription(String x) { description=x; }
    public String getTheme() { return theme; } public void setTheme(String x) { theme=x; }
    public boolean isActive() { return active; } public void setActive(boolean x) { active=x; }
}
