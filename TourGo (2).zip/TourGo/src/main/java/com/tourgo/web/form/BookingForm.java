package com.tourgo.web.form;

import jakarta.validation.constraints.*;

public class BookingForm {
    @NotNull(message="Chọn lịch khởi hành")
    private Long departureId;
    @Min(value=1,message="Ít nhất 1 khách") @Max(value=30,message="Tối đa 30 khách/đơn")
    private int travelers = 1;
    @NotBlank(message="Vui lòng nhập họ tên") @Size(max=120)
    private String contactName;
    @NotBlank(message="Vui lòng nhập điện thoại")
    @Pattern(regexp="^[0-9+().\\s-]{9,24}$", message="Số điện thoại không hợp lệ")
    private String contactPhone;
    @Size(max=500)
    private String note;
    public Long getDepartureId() { return departureId; } public void setDepartureId(Long x) { departureId=x; }
    public int getTravelers() { return travelers; } public void setTravelers(int x) { travelers=x; }
    public String getContactName() { return contactName; } public void setContactName(String x) { contactName=x; }
    public String getContactPhone() { return contactPhone; } public void setContactPhone(String x) { contactPhone=x; }
    public String getNote() { return note; } public void setNote(String x) { note=x; }
}
