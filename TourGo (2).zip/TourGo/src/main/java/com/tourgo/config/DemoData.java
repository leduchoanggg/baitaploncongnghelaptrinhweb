package com.tourgo.config;

import com.tourgo.model.*;
import com.tourgo.repository.*;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.math.BigDecimal;
import java.time.LocalDate;

@Configuration
public class DemoData {
    @Bean
    @ConditionalOnProperty(name="app.seed-demo", havingValue="true", matchIfMissing=true)
    ApplicationRunner seed(UserRepository users, TourRepository tours,
                           DepartureRepository departures, PasswordEncoder encoder) {
        return args -> {
            createUser(users, encoder, "Quản trị TourGo", "admin@tourgo.local", "Admin@12345", UserRole.ADMIN);
            createUser(users, encoder, "Khách hàng Demo", "khach@tourgo.local", "Customer@12345", UserRole.CUSTOMER);
            if (tours.count() != 0) return; // không ghi đè dữ liệu sẵn có
            Tour hanoi = makeTour(tours, "Hà Nội – Sapa 3N2Đ", "Sapa", "Hà Nội", 3, "2690000",
                "Săn mây Fansipan, bản Cát Cát và ẩm thực Tây Bắc.",
                "Khởi hành từ Hà Nội, tham quan bản Cát Cát, trải nghiệm cáp treo Fansipan, ăn đặc sản vùng cao.", "mountain");
            Tour halong = makeTour(tours, "Vịnh Hạ Long 2N1Đ", "Hạ Long", "Hà Nội", 2, "3190000",
                "Du thuyền ngắm vịnh, chèo kayak và nghỉ đêm trên biển.",
                "Du thuyền khám phá di sản Hạ Long, ghé hang động, thưởng thức hải sản và nghỉ đêm.", "sea");
            Tour danang = makeTour(tours, "Đà Nẵng – Hội An 4N3Đ", "Đà Nẵng", "Hà Nội", 4, "4990000",
                "Biển Mỹ Khê, Bà Nà Hills và phố cổ Hội An.",
                "Trọn bộ trải nghiệm Đà Nẵng, Bà Nà Hills, Hội An và những món ăn địa phương.", "city");
            Tour dalat = makeTour(tours, "Đà Lạt mộng mơ 3N2Đ", "Đà Lạt", "TP. HCM", 3, "2890000",
                "Rừng thông, thác nước và những quán cà phê phố núi.",
                "Tham quan hồ Tuyền Lâm, thác Datanla, trải nghiệm không khí cao nguyên.", "forest");
            departure(departures, hanoi, 7, 25);
            departure(departures, hanoi, 21, 25);
            departure(departures, halong, 10, 18);
            departure(departures, halong, 24, 18);
            departure(departures, danang, 14, 30);
            departure(departures, dalat, 17, 22);
        };
    }

    private static void createUser(UserRepository users, PasswordEncoder encoder,
                                   String name, String email, String password, UserRole role) {
        if (users.existsByEmailIgnoreCase(email)) return;
        AppUser u = new AppUser();
        u.setFullName(name); u.setEmail(email); u.setPasswordHash(encoder.encode(password)); u.setRole(role);
        users.save(u);
    }
    private static Tour makeTour(TourRepository repo, String name, String to, String from,
                                 int days, String price, String summary, String description, String theme) {
        Tour t = new Tour();
        t.setTitle(name); t.setDestination(to); t.setOrigin(from); t.setDurationDays(days);
        t.setPrice(new BigDecimal(price)); t.setSummary(summary);
        t.setDescription(description); t.setTheme(theme);
        return repo.save(t);
    }
    private static void departure(DepartureRepository repo, Tour tour, int days, int seats) {
        TourDeparture d = new TourDeparture();
        d.setTour(tour); d.setStartDate(LocalDate.now().plusDays(days));
        d.setCapacity(seats); d.setAvailableSeats(seats);
        repo.save(d);
    }
}
