package com.tourgo.service;

import com.tourgo.model.*;
import com.tourgo.repository.*;
import com.tourgo.web.form.BookingForm;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;

@Service
public class BookingService {
    private final UserRepository users;
    private final DepartureRepository departures;
    private final BookingRepository bookings;

    public BookingService(UserRepository users, DepartureRepository departures, BookingRepository bookings) {
        this.users=users; this.departures=departures; this.bookings=bookings;
    }
    @Transactional
    public Booking place(BookingForm form, String email) {
        // Pessimistic lock: nhiều khách đồng thời không thể đặt vượt số chỗ.
        TourDeparture d = departures.lockById(form.getDepartureId())
            .orElseThrow(() -> new IllegalArgumentException("Lịch khởi hành không tồn tại"));
        if (!d.isActive() || !d.getTour().isActive() || !d.getStartDate().isAfter(LocalDate.now()))
            throw new IllegalArgumentException("Lịch khởi hành không còn mở bán");
        if (form.getTravelers() <= 0)
            throw new IllegalArgumentException("Số lượng khách phải lớn hơn 0");
        if (form.getTravelers() > d.getAvailableSeats())
            throw new IllegalArgumentException("Chỉ còn " + d.getAvailableSeats() + " chỗ trống");
        AppUser customer = users.findByEmailIgnoreCase(email)
            .orElseThrow(() -> new IllegalArgumentException("Tài khoản không tồn tại"));
        Booking b = new Booking();
        b.setCustomer(customer); b.setDeparture(d); b.setTravelers(form.getTravelers());
        b.setContactName(form.getContactName().trim()); b.setContactPhone(form.getContactPhone().trim());
        b.setNote(form.getNote() == null ? "" : form.getNote().trim());
        b.setTotalPrice(d.getTour().getPrice().multiply(java.math.BigDecimal.valueOf(form.getTravelers())));
        b.setStatus(BookingStatus.PENDING);
        d.setAvailableSeats(d.getAvailableSeats() - form.getTravelers());
        return bookings.save(b);
    }

    @Transactional
    public void cancelByCustomer(Long id, String email) {
        Booking b = bookings.lockById(id)
            .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy đơn đặt tour"));
        if (!b.getCustomer().getEmail().equalsIgnoreCase(email))
            throw new IllegalArgumentException("Bạn không sở hữu đơn đặt tour này");
        if (b.getStatus() != BookingStatus.PENDING)
            throw new IllegalArgumentException("Chỉ hủy được đơn đang chờ duyệt");
        b.setStatus(BookingStatus.CANCELLED);
        releaseSeats(b);
    }

    @Transactional
    public void adminChangeStatus(Long id, BookingStatus next) {
        if (next != BookingStatus.CONFIRMED && next != BookingStatus.REJECTED)
            throw new IllegalArgumentException("Trạng thái không hợp lệ");
        Booking b = bookings.lockById(id)
            .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy đơn đặt tour"));
        if (b.getStatus() != BookingStatus.PENDING)
            throw new IllegalArgumentException("Đơn này đã được xử lý");
        b.setStatus(next);
        if (next == BookingStatus.REJECTED) releaseSeats(b);
    }

    private void releaseSeats(Booking b) {
        TourDeparture d = departures.lockById(b.getDeparture().getId())
            .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy lịch khởi hành"));

        int restoredSeats = d.getAvailableSeats() + b.getTravelers();

        if (restoredSeats > d.getCapacity()) {
            throw new IllegalStateException("Số chỗ hoàn trả vượt quá sức chứa");
        }

        d.setAvailableSeats(restoredSeats);
    }  
}
