package com.tourgo.service;

import com.tourgo.model.Tour;
import com.tourgo.model.TourDeparture;
import com.tourgo.repository.*;
import com.tourgo.web.form.DepartureForm;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DepartureService {
    private final TourRepository tours;
    private final DepartureRepository departures;
    public DepartureService(TourRepository tours, DepartureRepository departures) {
        this.tours=tours; this.departures=departures;
    }

    @Transactional
    public void save(Long id, DepartureForm form) {
        if (form.getCapacity() <= 0) {
        throw new IllegalArgumentException("Sức chứa phải lớn hơn 0");
        }
        if (form.getStartDate() == null ||
            !form.getStartDate().isAfter(java.time.LocalDate.now())) {
            throw new IllegalArgumentException("Ngày khởi hành phải lớn hơn ngày hiện tại");
}
        Tour t = tours.findById(form.getTourId())
            .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy tour"));
        TourDeparture d;
        if (id == null) {
            d = new TourDeparture();
            d.setTour(t);
            d.setAvailableSeats(form.getCapacity());
        } else {
            d = departures.lockById(id)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy lịch khởi hành"));
            if (!d.getTour().getId().equals(t.getId()))
                throw new IllegalArgumentException("Không thể đổi tour của một lịch đã tạo");
            int reserved = d.getCapacity() - d.getAvailableSeats();
            if (form.getCapacity() < reserved)
                throw new IllegalArgumentException("Sức chứa mới thấp hơn số chỗ đã đặt: " + reserved);
            d.setAvailableSeats(form.getCapacity() - reserved);
        }
        d.setStartDate(form.getStartDate());
        d.setCapacity(form.getCapacity());
        d.setActive(form.isActive());
        departures.save(d);
    }

    @Transactional
    public void toggle(Long id) {
        TourDeparture d = departures.lockById(id)
            .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy lịch khởi hành"));
        d.setActive(!d.isActive());
    }
}
