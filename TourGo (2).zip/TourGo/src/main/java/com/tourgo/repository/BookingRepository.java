package com.tourgo.repository;

import com.tourgo.model.Booking;
import com.tourgo.model.BookingStatus;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;

public interface BookingRepository extends JpaRepository<Booking, Long> {

@Query("""
    select b from Booking b
    left join fetch b.departure d
    left join fetch d.tour
    where b.customer.id = :customerId
    order by b.id desc
    """)
List<Booking> findByCustomerIdOrderByIdDesc(
    @Param("customerId") Long customerId
);

    @Query("""
        select b from Booking b
        left join fetch b.customer
        left join fetch b.departure d
        left join fetch d.tour
        order by b.id desc
        """)
    List<Booking> findAllByOrderByIdDesc();

    long countByStatus(BookingStatus status);

    @Query("select sum(b.totalPrice) from Booking b where b.status = :status")
    BigDecimal sumByStatus(@Param("status") BookingStatus status);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select b from Booking b where b.id = :id")
    Optional<Booking> lockById(@Param("id") Long id);
}
