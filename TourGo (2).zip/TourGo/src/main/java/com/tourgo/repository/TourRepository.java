package com.tourgo.repository;

import com.tourgo.model.Tour;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface TourRepository extends JpaRepository<Tour, Long> {
    List<Tour> findAllByOrderByIdDesc();
    @Query("select t from Tour t where t.active = true and " +
           "(lower(t.title) like lower(concat('%', :q, '%')) or " +
           "lower(t.destination) like lower(concat('%', :q, '%')) or " +
           "lower(t.origin) like lower(concat('%', :q, '%'))) order by t.id desc")
    List<Tour> searchActive(@Param("q") String query);
    long countByActiveTrue();
}
