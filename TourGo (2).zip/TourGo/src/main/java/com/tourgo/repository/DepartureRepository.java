
package com.tourgo.repository;

import com.tourgo.model.TourDeparture;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface DepartureRepository extends JpaRepository<TourDeparture, Long> {

    @Query("""
        select d from TourDeparture d
        join fetch d.tour
        order by d.startDate asc
        """)
    List<TourDeparture> findAllByOrderByStartDateAsc();

    List<TourDeparture> findByTourIdAndActiveTrueAndStartDateGreaterThanEqualOrderByStartDateAsc(
            Long tourId, LocalDate from);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select d from TourDeparture d where d.id = :id")
    Optional<TourDeparture> lockById(@Param("id") Long id);
}
