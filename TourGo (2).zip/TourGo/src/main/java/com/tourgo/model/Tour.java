package com.tourgo.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "tours")
public class Tour {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 150)
    private String title;
    @Column(nullable = false, length = 100)
    private String destination;
    @Column(nullable = false, length = 100)
    private String origin;
    @Column(nullable = false)
    private int durationDays;
    @Column(nullable = false, precision = 14, scale = 0)
    private BigDecimal price;
    @Column(nullable = false, length = 300)
    private String summary;
    @Column(columnDefinition = "text")
    private String description;
    @Column(nullable = false, length = 24)
    private String theme = "sea";
    @Column(nullable = false)
    private boolean active = true;

    public Long getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }
    public int getDurationDays() { return durationDays; }
    public void setDurationDays(int durationDays) { this.durationDays = durationDays; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getTheme() { return theme; }
    public void setTheme(String theme) { this.theme = theme; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
