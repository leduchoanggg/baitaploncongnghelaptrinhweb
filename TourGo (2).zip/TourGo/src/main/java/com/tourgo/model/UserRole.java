package com.tourgo.model;

public enum UserRole { ADMIN, CUSTOMER }
