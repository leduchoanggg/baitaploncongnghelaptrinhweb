package com.tourgo.model;

public enum BookingStatus { PENDING, CONFIRMED, REJECTED, CANCELLED }
