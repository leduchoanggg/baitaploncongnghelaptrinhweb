package com.tourgo.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "tour_departures")
public class TourDeparture {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "tour_id", nullable = false)
    private Tour tour;
    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;
    @Column(nullable = false)
    private int capacity;
    @Column(name = "available_seats", nullable = false)
    private int availableSeats;
    @Column(nullable = false)
    private boolean active = true;
    @Version
    private long version;

    public Long getId() { return id; }
    public Tour getTour() { return tour; }
    public void setTour(Tour tour) { this.tour = tour; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public int getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(int availableSeats) { this.availableSeats = availableSeats; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
