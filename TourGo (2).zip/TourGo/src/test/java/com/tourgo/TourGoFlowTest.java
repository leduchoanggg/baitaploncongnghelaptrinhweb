package com.tourgo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.transaction.annotation.Transactional;

import com.tourgo.model.Booking;
import com.tourgo.model.BookingStatus;
import com.tourgo.model.TourDeparture;
import com.tourgo.repository.BookingRepository;
import com.tourgo.repository.DepartureRepository;
import com.tourgo.repository.TourRepository;
import com.tourgo.repository.UserRepository;
import com.tourgo.service.BookingService;
import com.tourgo.web.form.BookingForm;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class TourGoFlowTest {
    @Autowired MockMvc mvc;
    @Autowired UserRepository users;
    @Autowired TourRepository tours;
    @Autowired DepartureRepository departures;
    @Autowired BookingRepository bookings;
    @Autowired BookingService bookingService;

    @Test
    void publicPagesAndTemplateRender() throws Exception {
        mvc.perform(get("/")).andExpect(status().isOk());
        mvc.perform(get("/login")).andExpect(status().isOk());
        mvc.perform(get("/register")).andExpect(status().isOk());
        Long id = tours.findAll().get(0).getId();
        mvc.perform(get("/tours/"+id)).andExpect(status().isOk());
    }

    @Test
    void adminAndCustomerRolesAreSeparate() throws Exception {
        mvc.perform(get("/admin").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("admin@tourgo.local").roles("ADMIN")))
            .andExpect(status().isOk());
        mvc.perform(get("/admin").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("khach@tourgo.local").roles("CUSTOMER")))
            .andExpect(status().isForbidden());
        mvc.perform(get("/customer/bookings").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("khach@tourgo.local").roles("CUSTOMER")))
            .andExpect(status().isOk());
        mvc.perform(get("/customer/bookings").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("admin@tourgo.local").roles("ADMIN")))
            .andExpect(status().isForbidden());
        mvc.perform(get("/admin/tours").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("admin@tourgo.local").roles("ADMIN")))
            .andExpect(status().isOk());
        mvc.perform(get("/admin/tours/new").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("admin@tourgo.local").roles("ADMIN")))
            .andExpect(status().isOk());
        mvc.perform(get("/admin/departures").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("admin@tourgo.local").roles("ADMIN")))
            .andExpect(status().isOk());
        mvc.perform(get("/admin/departures/new").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("admin@tourgo.local").roles("ADMIN")))
            .andExpect(status().isOk());
        mvc.perform(get("/admin/bookings").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("admin@tourgo.local").roles("ADMIN")))
            .andExpect(status().isOk());
        mvc.perform(get("/admin/customers").with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user("admin@tourgo.local").roles("ADMIN")))
            .andExpect(status().isOk());
    }

    @Test
    void realAdminLoginRedirectsToAdmin() throws Exception {
        MvcResult adminLogin = mvc.perform(post("/login").with(csrf())
                .param("username", "admin@tourgo.local")
                .param("password", "Admin@12345"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/admin")).andReturn();
        MockHttpSession session = (MockHttpSession) adminLogin.getRequest().getSession(false);
        assertNotNull(session, "Login phai tao session");
        mvc.perform(get("/admin").session(session)).andExpect(status().isOk());
        mvc.perform(post("/login").with(csrf())
                .param("username", "khach@tourgo.local")
                .param("password", "Customer@12345"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/customer/bookings"));
    }

    @Test
    void formPostRequiresCsrf() throws Exception {
        mvc.perform(post("/login").param("username", "admin@tourgo.local").param("password", "Admin@12345"))
            .andExpect(status().isForbidden());
    }

    @Test
    @Transactional
    void bookingHoldsAndReleasesSeats() {
        TourDeparture d = departures.findAll().get(0);
        int before = d.getAvailableSeats();
        BookingForm form = new BookingForm();
        form.setDepartureId(d.getId()); form.setTravelers(2);
        form.setContactName("Nguyễn Văn B"); form.setContactPhone("0912345678");
        Booking booking = bookingService.place(form, "khach@tourgo.local");
        assertEquals(BookingStatus.PENDING, booking.getStatus());
        assertEquals(before - 2, departures.findById(d.getId()).orElseThrow().getAvailableSeats());
        bookingService.cancelByCustomer(booking.getId(), "khach@tourgo.local");
        assertEquals(BookingStatus.CANCELLED, bookings.findById(booking.getId()).orElseThrow().getStatus());
        assertEquals(before, departures.findById(d.getId()).orElseThrow().getAvailableSeats());
    }
}
